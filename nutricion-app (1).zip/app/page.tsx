"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { ArrowRight, Settings } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"

export default function HomePage() {
  const [userType, setUserType] = useState<"profesional" | "usuario">("profesional")

  return (
    <div className="container mx-auto py-10 px-4 max-w-5xl">
      <div className="text-center mb-10 relative">
        <h1 className="text-4xl font-bold tracking-tight mb-4">NutriSport</h1>
        <p className="text-xl text-muted-foreground">Plataforma de nutrición y rendimiento deportivo</p>
        <Dialog>
          <DialogTrigger asChild>
            <Button variant="ghost" size="icon" className="absolute right-0 top-0">
              <Settings className="h-5 w-5" />
              <span className="sr-only">Configuración</span>
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Configuración de acceso</DialogTitle>
              <DialogDescription>
                Selecciona el tipo de usuario con el que deseas acceder a la plataforma.
              </DialogDescription>
            </DialogHeader>
            <RadioGroup
              value={userType}
              onValueChange={(value) => setUserType(value as "profesional" | "usuario")}
              className="grid gap-4 py-4"
            >
              <div className="flex items-center space-x-2 border p-4 rounded-md">
                <RadioGroupItem value="profesional" id="profesional" />
                <Label htmlFor="profesional" className="flex-1 cursor-pointer">
                  <div className="font-medium">Profesional</div>
                  <div className="text-sm text-muted-foreground">Nutricionistas y profesionales del deporte</div>
                </Label>
              </div>
              <div className="flex items-center space-x-2 border p-4 rounded-md">
                <RadioGroupItem value="usuario" id="usuario" />
                <Label htmlFor="usuario" className="flex-1 cursor-pointer">
                  <div className="font-medium">Usuario</div>
                  <div className="text-sm text-muted-foreground">Deportistas y atletas</div>
                </Label>
              </div>
            </RadioGroup>
            <div className="flex justify-end">
              <Button className="bg-violet-500 hover:bg-violet-600">Guardar preferencia</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="border-violet-100 dark:border-violet-900/20 hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle>Portal Profesional</CardTitle>
            <CardDescription>Acceso para nutricionistas y profesionales del deporte</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-6">Gestiona evaluaciones, planes nutricionales y seguimiento de pacientes deportistas.</p>
            <Button asChild className="w-full bg-violet-500 hover:bg-violet-600">
              <Link href="/profesional/inicio">
                Acceder al Portal Profesional <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardContent>
        </Card>

        <Card className="border-violet-100 dark:border-violet-900/20 hover:shadow-md transition-shadow">
          <CardHeader>
            <CardTitle>Portal Usuario</CardTitle>
            <CardDescription>Acceso para deportistas y atletas</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="mb-6">Consulta tus evaluaciones, plan nutricional y progreso deportivo.</p>
            <Button asChild className="w-full bg-violet-500 hover:bg-violet-600">
              <Link href="/usuario/inicio">
                Acceder al Portal Usuario <ArrowRight className="ml-2 h-4 w-4" />
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      <div className="mt-12 text-center">
        <p className="text-muted-foreground">© 2025 NutriSport - Plataforma de nutrición y rendimiento deportivo</p>
      </div>
    </div>
  )
}

