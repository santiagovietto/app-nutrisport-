"use client"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import {
  Edit,
  FileText,
  MessageSquare,
  Calendar,
  Mail,
  Phone,
  MapPin,
  Weight,
  Ruler,
  Activity,
  Heart,
  Upload,
  Download,
  Plus,
  LineChart,
  BarChart3,
  ArrowLeft,
  Save,
  Trash2,
  Clock,
  FileUp,
} from "lucide-react"
import Link from "next/link"

// Datos de ejemplo para un paciente específico
const paciente = {
  id: 1,
  nombre: "Carlos Rodríguez",
  deporte: "Fútbol",
  posicion: "Delantero",
  edad: 24,
  sexo: "Masculino",
  fechaNacimiento: "10/05/1999",
  email: "carlos.rodriguez@email.com",
  telefono: "+34 612 345 678",
  direccion: "Calle Ejemplo 123, Madrid",
  evaluaciones: [
    {
      fecha: "15/03/2025",
      peso: 75.2,
      talla: 180,
      imc: 23.2,
      grasaCorporal: 12.5,
      pliegues: {
        tricipital: 8.2,
        subescapular: 9.5,
        bicipital: 4.3,
        suprailiaco: 7.8,
        abdominal: 12.1,
        muslo: 10.4,
        pantorrilla: 6.2,
      },
      perimetros: {
        brazoRelajado: 30.5,
        brazoContraido: 33.2,
        antebrazo: 27.8,
        cintura: 78.4,
        cadera: 95.2,
        muslo: 55.6,
        pantorrilla: 37.3,
      },
    },
    {
      fecha: "15/02/2025",
      peso: 76.1,
      talla: 180,
      imc: 23.5,
      grasaCorporal: 13.2,
      pliegues: {
        tricipital: 8.5,
        subescapular: 10.1,
        bicipital: 4.5,
        suprailiaco: 8.2,
        abdominal: 12.8,
        muslo: 10.9,
        pantorrilla: 6.5,
      },
      perimetros: {
        brazoRelajado: 30.3,
        brazoContraido: 33.0,
        antebrazo: 27.6,
        cintura: 79.1,
        cadera: 95.5,
        muslo: 55.3,
        pantorrilla: 37.1,
      },
    },
    {
      fecha: "15/01/2025",
      peso: 77.3,
      talla: 180,
      imc: 23.9,
      grasaCorporal: 14.1,
      pliegues: {
        tricipital: 9.1,
        subescapular: 10.8,
        bicipital: 4.9,
        suprailiaco: 8.7,
        abdominal: 13.5,
        muslo: 11.4,
        pantorrilla: 6.9,
      },
      perimetros: {
        brazoRelajado: 30.1,
        brazoContraido: 32.7,
        antebrazo: 27.4,
        cintura: 80.2,
        cadera: 96.1,
        muslo: 55.0,
        pantorrilla: 36.8,
      },
    },
  ],
  notas: [
    {
      fecha: "15/03/2025",
      texto:
        "El paciente muestra una mejora en su composición corporal. Se recomienda mantener el plan nutricional actual.",
    },
    {
      fecha: "15/02/2025",
      texto: "Ligero aumento de peso, pero dentro de los parámetros esperados para la fase de volumen.",
    },
    {
      fecha: "15/01/2025",
      texto:
        "Primera evaluación. Se establece plan nutricional enfocado en reducción de grasa corporal manteniendo masa muscular.",
    },
  ],
  planAlimentario: [
    {
      titulo: "Plan Nutricional - Fase de Definición",
      fecha: "15/03/2025",
      contenido: "Contenido del plan nutricional para la fase de definición...",
      archivo: "plan_nutricional_marzo_2025.pdf",
    },
    {
      titulo: "Plan Nutricional - Fase de Volumen",
      fecha: "15/01/2025",
      contenido: "Contenido del plan nutricional para la fase de volumen...",
      archivo: "plan_nutricional_enero_2025.pdf",
    },
  ],
  metas: [
    {
      titulo: "Reducción de grasa corporal",
      descripcion: "Reducir el porcentaje de grasa corporal al 10% manteniendo la masa muscular",
      fechaInicio: "15/01/2025",
      fechaFin: "15/04/2025",
      progreso: 70,
    },
    {
      titulo: "Mejora de VO2 máx",
      descripcion: "Aumentar el VO2 máx a 50 ml/kg/min",
      fechaInicio: "15/01/2025",
      fechaFin: "15/06/2025",
      progreso: 45,
    },
  ],
}

export default function PacienteDetalle({ params }: { params: { id: string } }) {
  const [activeTab, setActiveTab] = useState("datos")
  const [editingMeta, setEditingMeta] = useState<number | null>(null)
  const [editingPlan, setEditingPlan] = useState<number | null>(null)
  const [showAddPlan, setShowAddPlan] = useState(false)
  const [showAddMeta, setShowAddMeta] = useState(false)
  const [timeRange, setTimeRange] = useState("3m")
  const [chartType, setChartType] = useState("line")

  // Nuevos estados para formularios
  const [newPlan, setNewPlan] = useState({
    titulo: "",
    contenido: "",
    archivo: null as File | null,
  })

  const [newMeta, setNewMeta] = useState({
    titulo: "",
    descripcion: "",
    fechaInicio: new Date().toISOString().split("T")[0],
    fechaFin: "",
    progreso: 0,
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" asChild className="h-8 w-8">
          <Link href="/profesional/pacientes">
            <ArrowLeft className="h-4 w-4" />
          </Link>
        </Button>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">{paciente.nombre}</h1>
          <div className="flex flex-wrap gap-2 mt-1">
            <Badge className="bg-violet-500 hover:bg-violet-600">{paciente.deporte}</Badge>
            <Badge
              variant="outline"
              className="border-violet-200 dark:border-violet-800 bg-violet-50 dark:bg-violet-950/20"
            >
              {paciente.posicion}
            </Badge>
            <Badge
              variant="outline"
              className="border-violet-200 dark:border-violet-800 bg-violet-50 dark:bg-violet-950/20"
            >
              {paciente.edad} años
            </Badge>
            <Badge
              variant="outline"
              className="border-violet-200 dark:border-violet-800 bg-violet-50 dark:bg-violet-950/20"
            >
              {paciente.sexo}
            </Badge>
          </div>
        </div>
        <div className="ml-auto flex gap-2">
          <Button asChild className="bg-violet-500 hover:bg-violet-600">
            <Link href={`/profesional/evaluaciones/nueva?paciente=${params.id}`}>
              <FileText className="mr-2 h-4 w-4" /> Nueva Evaluación
            </Link>
          </Button>
        </div>
      </div>

      <Tabs defaultValue="datos" value={activeTab} onValueChange={setActiveTab} className="space-y-4">
        <TabsList className="bg-violet-50 dark:bg-violet-950/20 border border-violet-100 dark:border-violet-900/20">
          <TabsTrigger value="datos" className="data-[state=active]:bg-white dark:data-[state=active]:bg-background">
            Datos Personales
          </TabsTrigger>
          <TabsTrigger
            value="evaluaciones"
            className="data-[state=active]:bg-white dark:data-[state=active]:bg-background"
          >
            Evaluaciones
          </TabsTrigger>
          <TabsTrigger
            value="tendencias"
            className="data-[state=active]:bg-white dark:data-[state=active]:bg-background"
          >
            Tendencias
          </TabsTrigger>
          <TabsTrigger value="plan" className="data-[state=active]:bg-white dark:data-[state=active]:bg-background">
            Plan Alimentario
          </TabsTrigger>
          <TabsTrigger value="metas" className="data-[state=active]:bg-white dark:data-[state=active]:bg-background">
            Metas
          </TabsTrigger>
        </TabsList>

        {/* Pestaña de Datos Personales */}
        <TabsContent value="datos" className="space-y-4">
          <Card className="border-violet-100 dark:border-violet-900/20">
            <CardHeader>
              <CardTitle>Información Personal</CardTitle>
              <CardDescription>Datos básicos del paciente</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-violet-500" />
                  <div>
                    <p className="text-sm font-medium">Fecha de Nacimiento</p>
                    <p className="text-sm text-muted-foreground">{paciente.fechaNacimiento}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4 text-violet-500" />
                  <div>
                    <p className="text-sm font-medium">Email</p>
                    <p className="text-sm text-muted-foreground">{paciente.email}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="h-4 w-4 text-violet-500" />
                  <div>
                    <p className="text-sm font-medium">Teléfono</p>
                    <p className="text-sm text-muted-foreground">{paciente.telefono}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <MapPin className="h-4 w-4 text-violet-500" />
                  <div>
                    <p className="text-sm font-medium">Dirección</p>
                    <p className="text-sm text-muted-foreground">{paciente.direccion}</p>
                  </div>
                </div>
              </div>
              <div className="flex justify-end">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                >
                  <Edit className="mr-2 h-4 w-4" /> Editar Información
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-violet-100 dark:border-violet-900/20">
            <CardHeader>
              <CardTitle>Información Deportiva</CardTitle>
              <CardDescription>Datos relacionados con su actividad deportiva</CardDescription>
            </CardHeader>
            <CardContent className="grid gap-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <p className="text-sm font-medium">Deporte</p>
                  <p className="text-sm text-muted-foreground">{paciente.deporte}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Posición</p>
                  <p className="text-sm text-muted-foreground">{paciente.posicion}</p>
                </div>
                <div>
                  <p className="text-sm font-medium">Años de práctica</p>
                  <p className="text-sm text-muted-foreground">8 años</p>
                </div>
              </div>
              <div className="flex justify-end">
                <Button
                  variant="outline"
                  size="sm"
                  className="border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                >
                  <Edit className="mr-2 h-4 w-4" /> Editar Información
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-violet-100 dark:border-violet-900/20">
            <CardHeader>
              <CardTitle>Notas del Profesional</CardTitle>
              <CardDescription>Observaciones y recomendaciones</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {paciente.notas.map((nota, index) => (
                  <div key={index} className="border-b pb-4 last:border-0 last:pb-0">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm text-muted-foreground">{nota.fecha}</span>
                      <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                        <Edit className="h-4 w-4 text-violet-500" />
                      </Button>
                    </div>
                    <p className="text-sm">{nota.texto}</p>
                  </div>
                ))}
              </div>

              <div className="mt-6">
                <Button className="w-full bg-violet-500 hover:bg-violet-600">
                  <MessageSquare className="mr-2 h-4 w-4" /> Añadir Nueva Nota
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pestaña de Evaluaciones */}
        <TabsContent value="evaluaciones" className="space-y-4">
          <Card className="border-violet-100 dark:border-violet-900/20">
            <CardHeader>
              <CardTitle>Historial de Evaluaciones</CardTitle>
              <CardDescription>Registro de todas las evaluaciones antropométricas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                {paciente.evaluaciones.map((evaluacion, index) => (
                  <div key={index} className="border-b pb-6 last:border-0 last:pb-0">
                    <div className="flex items-center justify-between mb-4">
                      <h3 className="font-semibold">Evaluación {index + 1}</h3>
                      <div className="flex items-center gap-2">
                        <span className="text-sm text-muted-foreground">{evaluacion.fecha}</span>
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                        >
                          <Edit className="mr-2 h-3 w-3" /> Editar
                        </Button>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-1">
                          <Weight className="h-3 w-3 text-violet-500" />
                          <span className="text-xs font-medium">Peso</span>
                        </div>
                        <span className="text-sm">{evaluacion.peso} kg</span>
                      </div>
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-1">
                          <Ruler className="h-3 w-3 text-violet-500" />
                          <span className="text-xs font-medium">Talla</span>
                        </div>
                        <span className="text-sm">{evaluacion.talla} cm</span>
                      </div>
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-1">
                          <Activity className="h-3 w-3 text-violet-500" />
                          <span className="text-xs font-medium">IMC</span>
                        </div>
                        <span className="text-sm">{evaluacion.imc}</span>
                      </div>
                      <div className="flex flex-col gap-1">
                        <div className="flex items-center gap-1">
                          <Heart className="h-3 w-3 text-violet-500" />
                          <span className="text-xs font-medium">% Grasa</span>
                        </div>
                        <span className="text-sm">{evaluacion.grasaCorporal}%</span>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div>
                        <h4 className="text-sm font-medium mb-2">Pliegues (mm)</h4>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Tricipital:</span>
                            <span>{evaluacion.pliegues.tricipital}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Subescapular:</span>
                            <span>{evaluacion.pliegues.subescapular}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Bicipital:</span>
                            <span>{evaluacion.pliegues.bicipital}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Suprailiaco:</span>
                            <span>{evaluacion.pliegues.suprailiaco}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Abdominal:</span>
                            <span>{evaluacion.pliegues.abdominal}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Muslo:</span>
                            <span>{evaluacion.pliegues.muslo}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Pantorrilla:</span>
                            <span>{evaluacion.pliegues.pantorrilla}</span>
                          </div>
                        </div>
                      </div>

                      <div>
                        <h4 className="text-sm font-medium mb-2">Perímetros (cm)</h4>
                        <div className="grid grid-cols-2 gap-2 text-sm">
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Brazo relajado:</span>
                            <span>{evaluacion.perimetros.brazoRelajado}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Brazo contraído:</span>
                            <span>{evaluacion.perimetros.brazoContraido}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Antebrazo:</span>
                            <span>{evaluacion.perimetros.antebrazo}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Cintura:</span>
                            <span>{evaluacion.perimetros.cintura}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Cadera:</span>
                            <span>{evaluacion.perimetros.cadera}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Muslo:</span>
                            <span>{evaluacion.perimetros.muslo}</span>
                          </div>
                          <div className="flex justify-between">
                            <span className="text-muted-foreground">Pantorrilla:</span>
                            <span>{evaluacion.perimetros.pantorrilla}</span>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-6 flex justify-center">
                <Button asChild className="bg-violet-500 hover:bg-violet-600">
                  <Link href={`/profesional/evaluaciones/nueva?paciente=${params.id}`}>
                    <Plus className="mr-2 h-4 w-4" /> Nueva Evaluación
                  </Link>
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pestaña de Tendencias */}
        <TabsContent value="tendencias" className="space-y-4">
          <Card className="border-violet-100 dark:border-violet-900/20">
            <CardHeader>
              <CardTitle>Evolución de Métricas</CardTitle>
              <CardDescription>Gráficos de evolución de las principales métricas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex justify-between items-center mb-4">
                <div className="flex items-center gap-2">
                  <Button
                    variant={chartType === "line" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setChartType("line")}
                    className={
                      chartType === "line"
                        ? "bg-violet-500 hover:bg-violet-600"
                        : "border-violet-200 dark:border-violet-800"
                    }
                  >
                    <LineChart className="h-4 w-4 mr-1" /> Línea
                  </Button>
                  <Button
                    variant={chartType === "bar" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setChartType("bar")}
                    className={
                      chartType === "bar"
                        ? "bg-violet-500 hover:bg-violet-600"
                        : "border-violet-200 dark:border-violet-800"
                    }
                  >
                    <BarChart3 className="h-4 w-4 mr-1" /> Barras
                  </Button>
                </div>
                <Select value={timeRange} onValueChange={setTimeRange}>
                  <SelectTrigger className="w-[140px] border-violet-200 dark:border-violet-800">
                    <SelectValue placeholder="Período" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1m">Último mes</SelectItem>
                    <SelectItem value="3m">Últimos 3 meses</SelectItem>
                    <SelectItem value="6m">Últimos 6 meses</SelectItem>
                    <SelectItem value="1y">Último año</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-8">
                <div>
                  <h3 className="text-sm font-medium mb-4">Evolución del Peso (kg)</h3>
                  <div className="h-64 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground mb-2">Gráfico de evolución del peso</p>
                      <p className="text-xs text-muted-foreground">Haz clic para ver detalles</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-4">Evolución del % de Grasa Corporal</h3>
                  <div className="h-64 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground mb-2">Gráfico de evolución del % de grasa</p>
                      <p className="text-xs text-muted-foreground">Haz clic para ver detalles</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-4">Evolución del Somatotipo</h3>
                  <div className="h-64 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground mb-2">Gráfico de evolución del somatotipo</p>
                      <p className="text-xs text-muted-foreground">Haz clic para ver detalles</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-violet-100 dark:border-violet-900/20">
            <CardHeader>
              <CardTitle>Comparativas</CardTitle>
              <CardDescription>Comparación con población o grupo similar</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                <div>
                  <h3 className="text-sm font-medium mb-4">Comparativa con jugadores de fútbol (Delanteros)</h3>
                  <div className="h-64 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground mb-2">Gráfico comparativo con delanteros</p>
                      <p className="text-xs text-muted-foreground">Haz clic para ver detalles</p>
                    </div>
                  </div>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-4">Comparativa con población general (Hombres 20-25 años)</h3>
                  <div className="h-64 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground mb-2">Gráfico comparativo con población general</p>
                      <p className="text-xs text-muted-foreground">Haz clic para ver detalles</p>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pestaña de Plan Alimentario */}
        <TabsContent value="plan" className="space-y-4">
          <Card className="border-violet-100 dark:border-violet-900/20">
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Plan Alimentario</CardTitle>
                  <CardDescription>Planes nutricionales asignados al paciente</CardDescription>
                </div>
                <Button onClick={() => setShowAddPlan(!showAddPlan)} className="bg-violet-500 hover:bg-violet-600">
                  <Plus className="mr-2 h-4 w-4" /> Nuevo Plan
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {showAddPlan && (
                <div className="mb-6 p-4 border rounded-lg bg-violet-50 dark:bg-violet-950/20 border-violet-200 dark:border-violet-800">
                  <h3 className="text-lg font-medium mb-4">Añadir Nuevo Plan Alimentario</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Título</label>
                      <Input
                        placeholder="Título del plan alimentario"
                        className="mt-1 border-violet-200 dark:border-violet-800"
                        value={newPlan.titulo}
                        onChange={(e) => setNewPlan({ ...newPlan, titulo: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Contenido</label>
                      <Textarea
                        placeholder="Descripción detallada del plan alimentario..."
                        className="mt-1 min-h-[150px] border-violet-200 dark:border-violet-800"
                        value={newPlan.contenido}
                        onChange={(e) => setNewPlan({ ...newPlan, contenido: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Subir Archivo (PDF, Word)</label>
                      <div className="mt-1 flex items-center gap-2">
                        <Button
                          variant="outline"
                          className="w-full border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                        >
                          <Upload className="mr-2 h-4 w-4" /> Seleccionar Archivo
                        </Button>
                        <span className="text-sm text-muted-foreground">
                          {newPlan.archivo ? newPlan.archivo.name : "Ningún archivo seleccionado"}
                        </span>
                      </div>
                    </div>
                    <div className="flex justify-end gap-2 pt-2">
                      <Button
                        variant="outline"
                        onClick={() => setShowAddPlan(false)}
                        className="border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                      >
                        Cancelar
                      </Button>
                      <Button className="bg-violet-500 hover:bg-violet-600">
                        <Save className="mr-2 h-4 w-4" /> Guardar Plan
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                {paciente.planAlimentario.map((plan, index) => (
                  <div
                    key={index}
                    className={`border rounded-lg p-4 ${editingPlan === index ? "bg-violet-50 dark:bg-violet-950/20 border-violet-200 dark:border-violet-800" : ""}`}
                  >
                    {editingPlan === index ? (
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-medium">Título</label>
                          <Input defaultValue={plan.titulo} className="mt-1 border-violet-200 dark:border-violet-800" />
                        </div>
                        <div>
                          <label className="text-sm font-medium">Contenido</label>
                          <Textarea
                            defaultValue={plan.contenido}
                            className="mt-1 min-h-[150px] border-violet-200 dark:border-violet-800"
                          />
                        </div>
                        <div>
                          <label className="text-sm font-medium">Archivo Actual</label>
                          <div className="mt-1 flex items-center gap-2">
                            <span className="text-sm text-muted-foreground">{plan.archivo}</span>
                            <Button
                              variant="outline"
                              size="sm"
                              className="h-8 border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                            >
                              <Download className="h-4 w-4" />
                            </Button>
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Reemplazar Archivo</label>
                          <div className="mt-1">
                            <Button
                              variant="outline"
                              className="w-full border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                            >
                              <Upload className="mr-2 h-4 w-4" /> Seleccionar Nuevo Archivo
                            </Button>
                          </div>
                        </div>
                        <div className="flex justify-end gap-2 pt-2">
                          <Button
                            variant="outline"
                            onClick={() => setEditingPlan(null)}
                            className="border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                          >
                            Cancelar
                          </Button>
                          <Button className="bg-violet-500 hover:bg-violet-600">
                            <Save className="mr-2 h-4 w-4" /> Guardar Cambios
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="flex justify-between items-center mb-3">
                          <h3 className="font-medium">{plan.titulo}</h3>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground">{plan.fecha}</span>
                            <div className="flex gap-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0"
                                onClick={() => setEditingPlan(index)}
                              >
                                <Edit className="h-4 w-4 text-violet-500" />
                              </Button>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          </div>
                        </div>
                        <p className="text-sm mb-4">{plan.contenido}</p>
                        <div className="flex items-center gap-2">
                          <FileUp className="h-4 w-4 text-violet-500" />
                          <span className="text-sm">{plan.archivo}</span>
                          <Button
                            variant="outline"
                            size="sm"
                            className="ml-auto h-8 border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                          >
                            <Download className="mr-2 h-4 w-4" /> Descargar
                          </Button>
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Pestaña de Metas */}
        <TabsContent value="metas" className="space-y-4">
          <Card className="border-violet-100 dark:border-violet-900/20">
            <CardHeader>
              <div className="flex justify-between items-center">
                <div>
                  <CardTitle>Metas y Objetivos</CardTitle>
                  <CardDescription>Metas establecidas para el paciente</CardDescription>
                </div>
                <Button onClick={() => setShowAddMeta(!showAddMeta)} className="bg-violet-500 hover:bg-violet-600">
                  <Plus className="mr-2 h-4 w-4" /> Nueva Meta
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {showAddMeta && (
                <div className="mb-6 p-4 border rounded-lg bg-violet-50 dark:bg-violet-950/20 border-violet-200 dark:border-violet-800">
                  <h3 className="text-lg font-medium mb-4">Añadir Nueva Meta</h3>
                  <div className="space-y-4">
                    <div>
                      <label className="text-sm font-medium">Título</label>
                      <Input
                        placeholder="Título de la meta"
                        className="mt-1 border-violet-200 dark:border-violet-800"
                        value={newMeta.titulo}
                        onChange={(e) => setNewMeta({ ...newMeta, titulo: e.target.value })}
                      />
                    </div>
                    <div>
                      <label className="text-sm font-medium">Descripción</label>
                      <Textarea
                        placeholder="Descripción detallada de la meta..."
                        className="mt-1 border-violet-200 dark:border-violet-800"
                        value={newMeta.descripcion}
                        onChange={(e) => setNewMeta({ ...newMeta, descripcion: e.target.value })}
                      />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div>
                        <label className="text-sm font-medium">Fecha de Inicio</label>
                        <Input
                          type="date"
                          className="mt-1 border-violet-200 dark:border-violet-800"
                          value={newMeta.fechaInicio}
                          onChange={(e) => setNewMeta({ ...newMeta, fechaInicio: e.target.value })}
                        />
                      </div>
                      <div>
                        <label className="text-sm font-medium">Fecha de Finalización</label>
                        <Input
                          type="date"
                          className="mt-1 border-violet-200 dark:border-violet-800"
                          value={newMeta.fechaFin}
                          onChange={(e) => setNewMeta({ ...newMeta, fechaFin: e.target.value })}
                        />
                      </div>
                    </div>
                    <div>
                      <label className="text-sm font-medium">Progreso Inicial (%)</label>
                      <Input
                        type="number"
                        min="0"
                        max="100"
                        className="mt-1 border-violet-200 dark:border-violet-800"
                        value={newMeta.progreso}
                        onChange={(e) => setNewMeta({ ...newMeta, progreso: Number.parseInt(e.target.value) })}
                      />
                    </div>
                    <div className="flex justify-end gap-2 pt-2">
                      <Button
                        variant="outline"
                        onClick={() => setShowAddMeta(false)}
                        className="border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                      >
                        Cancelar
                      </Button>
                      <Button className="bg-violet-500 hover:bg-violet-600">
                        <Save className="mr-2 h-4 w-4" /> Guardar Meta
                      </Button>
                    </div>
                  </div>
                </div>
              )}

              <div className="space-y-4">
                {paciente.metas.map((meta, index) => (
                  <div
                    key={index}
                    className={`border rounded-lg p-4 ${editingMeta === index ? "bg-violet-50 dark:bg-violet-950/20 border-violet-200 dark:border-violet-800" : ""}`}
                  >
                    {editingMeta === index ? (
                      <div className="space-y-4">
                        <div>
                          <label className="text-sm font-medium">Título</label>
                          <Input defaultValue={meta.titulo} className="mt-1 border-violet-200 dark:border-violet-800" />
                        </div>
                        <div>
                          <label className="text-sm font-medium">Descripción</label>
                          <Textarea
                            defaultValue={meta.descripcion}
                            className="mt-1 border-violet-200 dark:border-violet-800"
                          />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <label className="text-sm font-medium">Fecha de Inicio</label>
                            <Input
                              type="date"
                              defaultValue={meta.fechaInicio}
                              className="mt-1 border-violet-200 dark:border-violet-800"
                            />
                          </div>
                          <div>
                            <label className="text-sm font-medium">Fecha de Finalización</label>
                            <Input
                              type="date"
                              defaultValue={meta.fechaFin}
                              className="mt-1 border-violet-200 dark:border-violet-800"
                            />
                          </div>
                        </div>
                        <div>
                          <label className="text-sm font-medium">Progreso (%)</label>
                          <Input
                            type="number"
                            min="0"
                            max="100"
                            defaultValue={meta.progreso}
                            className="mt-1 border-violet-200 dark:border-violet-800"
                          />
                        </div>
                        <div className="flex justify-end gap-2 pt-2">
                          <Button
                            variant="outline"
                            onClick={() => setEditingMeta(null)}
                            className="border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                          >
                            Cancelar
                          </Button>
                          <Button className="bg-violet-500 hover:bg-violet-600">
                            <Save className="mr-2 h-4 w-4" /> Guardar Cambios
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <div className="flex justify-between items-center mb-3">
                          <h3 className="font-medium">{meta.titulo}</h3>
                          <div className="flex items-center gap-2">
                            <div className="flex gap-1">
                              <Button
                                variant="ghost"
                                size="sm"
                                className="h-8 w-8 p-0"
                                onClick={() => setEditingMeta(index)}
                              >
                                <Edit className="h-4 w-4 text-violet-500" />
                              </Button>
                              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                                <Trash2 className="h-4 w-4 text-red-500" />
                              </Button>
                            </div>
                          </div>
                        </div>
                        <p className="text-sm mb-4">{meta.descripcion}</p>
                        <div className="flex items-center gap-2 mb-2 text-sm">
                          <Clock className="h-4 w-4 text-violet-500" />
                          <span className="text-muted-foreground">Período:</span>
                          <span>
                            {meta.fechaInicio} - {meta.fechaFin}
                          </span>
                        </div>
                        <div className="space-y-2">
                          <div className="flex justify-between text-sm">
                            <span className="font-medium">Progreso</span>
                            <span>{meta.progreso}%</span>
                          </div>
                          <div className="w-full bg-violet-100 dark:bg-violet-950/40 rounded-full h-2.5">
                            <div
                              className="bg-violet-500 h-2.5 rounded-full"
                              style={{ width: `${meta.progreso}%` }}
                            ></div>
                          </div>
                        </div>
                      </>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

