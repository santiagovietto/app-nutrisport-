"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Plus, Filter, Calendar, Activity, Weight, Heart } from "lucide-react"
import Link from "next/link"
import { Badge } from "@/components/ui/badge"

// Datos de ejemplo
const pacientes = [
  {
    id: 1,
    nombre: "Carlos Rodríguez",
    deporte: "Fútbol",
    posicion: "Delantero",
    edad: 24,
    sexo: "Masculino",
    ultimaEval: "22/03/2025",
    metricas: { peso: 75.2, grasa: 12.5, vo2: 48.3 },
  },
  {
    id: 2,
    nombre: "Ana Martínez",
    deporte: "Baloncesto",
    posicion: "Base",
    edad: 22,
    sexo: "Femenino",
    ultimaEval: "15/03/2025",
    metricas: { peso: 62.4, grasa: 18.2, vo2: 42.1 },
  },
  {
    id: 3,
    nombre: "Juan López",
    deporte: "Natación",
    posicion: "Velocista",
    edad: 19,
    sexo: "Masculino",
    ultimaEval: "10/03/2025",
    metricas: { peso: 80.1, grasa: 14.3, vo2: 46.8 },
  },
  {
    id: 4,
    nombre: "María García",
    deporte: "Atletismo",
    posicion: "Fondista",
    edad: 26,
    sexo: "Femenino",
    ultimaEval: "05/03/2025",
    metricas: { peso: 58.7, grasa: 19.5, vo2: 44.2 },
  },
  {
    id: 5,
    nombre: "Pedro Sánchez",
    deporte: "Fútbol",
    posicion: "Defensa",
    edad: 28,
    sexo: "Masculino",
    ultimaEval: "01/03/2025",
    metricas: { peso: 82.3, grasa: 15.8, vo2: 45.6 },
  },
  {
    id: 6,
    nombre: "Laura Fernández",
    deporte: "Tenis",
    posicion: "Individual",
    edad: 21,
    sexo: "Femenino",
    ultimaEval: "28/02/2025",
    metricas: { peso: 61.5, grasa: 17.9, vo2: 43.8 },
  },
  {
    id: 7,
    nombre: "Miguel Torres",
    deporte: "Baloncesto",
    posicion: "Alero",
    edad: 25,
    sexo: "Masculino",
    ultimaEval: "25/02/2025",
    metricas: { peso: 78.9, grasa: 13.2, vo2: 47.5 },
  },
  {
    id: 8,
    nombre: "Sofía Ruiz",
    deporte: "Natación",
    posicion: "Fondista",
    edad: 23,
    sexo: "Femenino",
    ultimaEval: "20/02/2025",
    metricas: { peso: 60.2, grasa: 18.5, vo2: 44.9 },
  },
  {
    id: 9,
    nombre: "Javier Gómez",
    deporte: "Atletismo",
    posicion: "Velocista",
    edad: 27,
    sexo: "Masculino",
    ultimaEval: "15/02/2025",
    metricas: { peso: 76.8, grasa: 11.9, vo2: 49.2 },
  },
  {
    id: 10,
    nombre: "Carmen Díaz",
    deporte: "Fútbol",
    posicion: "Centrocampista",
    edad: 20,
    sexo: "Femenino",
    ultimaEval: "10/02/2025",
    metricas: { peso: 59.8, grasa: 19.1, vo2: 43.5 },
  },
]

export default function PacientesPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [filteredPacientes, setFilteredPacientes] = useState(pacientes)
  const [showFilters, setShowFilters] = useState(false)
  const [viewMode, setViewMode] = useState("cards")
  const [filterDeporte, setFilterDeporte] = useState("")
  const [filterSexo, setFilterSexo] = useState("")
  const [filterEdad, setFilterEdad] = useState("")
  const [filterPosicion, setFilterPosicion] = useState("")

  const handleSearch = (e: React.ChangeEvent<HTMLInputElement>) => {
    const term = e.target.value
    setSearchTerm(term)
    applyFilters(term, filterDeporte, filterSexo, filterEdad, filterPosicion)
  }

  const applyFilters = (term: string, deporte: string, sexo: string, edad: string, posicion: string) => {
    let filtered = pacientes.filter((paciente) => paciente.nombre.toLowerCase().includes(term.toLowerCase()))

    if (deporte) {
      filtered = filtered.filter((p) => p.deporte.toLowerCase() === deporte.toLowerCase())
    }

    if (sexo) {
      filtered = filtered.filter((p) => p.sexo.toLowerCase() === sexo.toLowerCase())
    }

    if (edad) {
      const [min, max] = edad.split("-").map(Number)
      if (max) {
        filtered = filtered.filter((p) => p.edad >= min && p.edad <= max)
      } else {
        filtered = filtered.filter((p) => p.edad >= min)
      }
    }

    if (posicion) {
      filtered = filtered.filter((p) => p.posicion.toLowerCase() === posicion.toLowerCase())
    }

    setFilteredPacientes(filtered)
  }

  const handleFilterChange = (filter: string, value: string) => {
    switch (filter) {
      case "deporte":
        setFilterDeporte(value)
        applyFilters(searchTerm, value, filterSexo, filterEdad, filterPosicion)
        break
      case "sexo":
        setFilterSexo(value)
        applyFilters(searchTerm, filterDeporte, value, filterEdad, filterPosicion)
        break
      case "edad":
        setFilterEdad(value)
        applyFilters(searchTerm, filterDeporte, filterSexo, value, filterPosicion)
        break
      case "posicion":
        setFilterPosicion(value)
        applyFilters(searchTerm, filterDeporte, filterSexo, filterEdad, value)
        break
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">Pacientes</h1>
        <Button asChild className="bg-violet-500 hover:bg-violet-600">
          <Link href="/profesional/pacientes/nuevo">
            <Plus className="mr-2 h-4 w-4" /> Nuevo Paciente
          </Link>
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Buscar paciente..."
            className="pl-8 border-violet-200 dark:border-violet-800"
            value={searchTerm}
            onChange={handleSearch}
          />
        </div>
        <Button
          variant="outline"
          onClick={() => setShowFilters(!showFilters)}
          className="sm:w-auto w-full border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
        >
          <Filter className="mr-2 h-4 w-4" />
          {showFilters ? "Ocultar filtros" : "Mostrar filtros"}
        </Button>
        <div className="flex border rounded-md overflow-hidden">
          <Button
            variant={viewMode === "cards" ? "default" : "ghost"}
            size="sm"
            onClick={() => setViewMode("cards")}
            className={viewMode === "cards" ? "bg-violet-500 hover:bg-violet-600 rounded-none" : "rounded-none"}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="mr-1"
            >
              <rect width="7" height="7" x="3" y="3" rx="1" />
              <rect width="7" height="7" x="14" y="3" rx="1" />
              <rect width="7" height="7" x="14" y="14" rx="1" />
              <rect width="7" height="7" x="3" y="14" rx="1" />
            </svg>
            Tarjetas
          </Button>
          <Button
            variant={viewMode === "list" ? "default" : "ghost"}
            size="sm"
            onClick={() => setViewMode("list")}
            className={viewMode === "list" ? "bg-violet-500 hover:bg-violet-600 rounded-none" : "rounded-none"}
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              strokeWidth="2"
              strokeLinecap="round"
              strokeLinejoin="round"
              className="mr-1"
            >
              <line x1="8" x2="21" y1="6" y2="6" />
              <line x1="8" x2="21" y1="12" y2="12" />
              <line x1="8" x2="21" y1="18" y2="18" />
              <line x1="3" x2="3.01" y1="6" y2="6" />
              <line x1="3" x2="3.01" y1="12" y2="12" />
              <line x1="3" x2="3.01" y1="18" y2="18" />
            </svg>
            Lista
          </Button>
        </div>
      </div>

      {showFilters && (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-violet-50 dark:bg-violet-950/20 rounded-lg">
          <div className="space-y-2">
            <label className="text-sm font-medium">Deporte</label>
            <Select value={filterDeporte} onValueChange={(value) => handleFilterChange("deporte", value)}>
              <SelectTrigger className="border-violet-200 dark:border-violet-800">
                <SelectValue placeholder="Todos los deportes" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los deportes</SelectItem>
                <SelectItem value="fútbol">Fútbol</SelectItem>
                <SelectItem value="baloncesto">Baloncesto</SelectItem>
                <SelectItem value="natación">Natación</SelectItem>
                <SelectItem value="atletismo">Atletismo</SelectItem>
                <SelectItem value="tenis">Tenis</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Sexo</label>
            <Select value={filterSexo} onValueChange={(value) => handleFilterChange("sexo", value)}>
              <SelectTrigger className="border-violet-200 dark:border-violet-800">
                <SelectValue placeholder="Todos" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos</SelectItem>
                <SelectItem value="masculino">Masculino</SelectItem>
                <SelectItem value="femenino">Femenino</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Rango de edad</label>
            <Select value={filterEdad} onValueChange={(value) => handleFilterChange("edad", value)}>
              <SelectTrigger className="border-violet-200 dark:border-violet-800">
                <SelectValue placeholder="Todas las edades" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las edades</SelectItem>
                <SelectItem value="18-20">18-20 años</SelectItem>
                <SelectItem value="21-25">21-25 años</SelectItem>
                <SelectItem value="26-30">26-30 años</SelectItem>
                <SelectItem value="31-100">31+ años</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <label className="text-sm font-medium">Posición</label>
            <Select value={filterPosicion} onValueChange={(value) => handleFilterChange("posicion", value)}>
              <SelectTrigger className="border-violet-200 dark:border-violet-800">
                <SelectValue placeholder="Todas las posiciones" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las posiciones</SelectItem>
                <SelectItem value="delantero">Delantero</SelectItem>
                <SelectItem value="defensa">Defensa</SelectItem>
                <SelectItem value="centrocampista">Centrocampista</SelectItem>
                <SelectItem value="base">Base</SelectItem>
                <SelectItem value="alero">Alero</SelectItem>
                <SelectItem value="velocista">Velocista</SelectItem>
                <SelectItem value="fondista">Fondista</SelectItem>
                <SelectItem value="individual">Individual</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      )}

      {filteredPacientes.length === 0 ? (
        <div className="flex flex-col items-center justify-center p-8 text-center">
          <div className="h-16 w-16 rounded-full bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center mb-4">
            <Search className="h-8 w-8 text-violet-500" />
          </div>
          <h3 className="text-lg font-medium mb-2">No se encontraron pacientes</h3>
          <p className="text-muted-foreground mb-4">Prueba con otros criterios de búsqueda o añade un nuevo paciente</p>
          <Button asChild className="bg-violet-500 hover:bg-violet-600">
            <Link href="/profesional/pacientes/nuevo">
              <Plus className="mr-2 h-4 w-4" /> Nuevo Paciente
            </Link>
          </Button>
        </div>
      ) : viewMode === "cards" ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredPacientes.map((paciente) => (
            <Link href={`/profesional/pacientes/${paciente.id}`} key={paciente.id}>
              <Card className="cursor-pointer hover:shadow-md transition-shadow border-violet-100 dark:border-violet-900/20">
                <CardContent className="p-4">
                  <div className="flex items-center gap-4">
                    <div className="h-12 w-12 rounded-full bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center text-violet-700 dark:text-violet-300 font-semibold">
                      {paciente.nombre
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </div>
                    <div className="flex-1">
                      <h3 className="font-medium">{paciente.nombre}</h3>
                      <div className="flex flex-wrap gap-2 mt-1">
                        <Badge className="bg-violet-500 hover:bg-violet-600">{paciente.deporte}</Badge>
                        <Badge
                          variant="outline"
                          className="border-violet-200 dark:border-violet-800 bg-violet-50 dark:bg-violet-950/20"
                        >
                          {paciente.posicion}
                        </Badge>
                        <Badge
                          variant="outline"
                          className="border-violet-200 dark:border-violet-800 bg-violet-50 dark:bg-violet-950/20"
                        >
                          {paciente.edad} años
                        </Badge>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2 mt-4">
                    <div className="flex flex-col items-center p-2 rounded-lg bg-violet-50 dark:bg-violet-950/20">
                      <Weight className="h-4 w-4 text-violet-500 mb-1" />
                      <span className="text-xs text-muted-foreground">Peso</span>
                      <span className="font-medium">{paciente.metricas.peso} kg</span>
                    </div>
                    <div className="flex flex-col items-center p-2 rounded-lg bg-violet-50 dark:bg-violet-950/20">
                      <Activity className="h-4 w-4 text-violet-500 mb-1" />
                      <span className="text-xs text-muted-foreground">% Grasa</span>
                      <span className="font-medium">{paciente.metricas.grasa}%</span>
                    </div>
                    <div className="flex flex-col items-center p-2 rounded-lg bg-violet-50 dark:bg-violet-950/20">
                      <Heart className="h-4 w-4 text-violet-500 mb-1" />
                      <span className="text-xs text-muted-foreground">VO2 Máx</span>
                      <span className="font-medium">{paciente.metricas.vo2}</span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center mt-4 text-xs text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      <span>Última evaluación: {paciente.ultimaEval}</span>
                    </div>
                    <Badge
                      variant="outline"
                      className="text-xs border-violet-200 dark:border-violet-800 bg-violet-50 dark:bg-violet-950/20"
                    >
                      {paciente.sexo}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>
      ) : (
        <div className="border rounded-lg overflow-hidden">
          <div className="grid grid-cols-12 gap-4 p-3 font-medium bg-violet-50 dark:bg-violet-950/20 border-b">
            <div className="col-span-4">Paciente</div>
            <div className="col-span-2">Deporte</div>
            <div className="col-span-2">Edad / Sexo</div>
            <div className="col-span-2">Última Eval.</div>
            <div className="col-span-2">Métricas</div>
          </div>
          <div className="divide-y">
            {filteredPacientes.map((paciente) => (
              <Link
                href={`/profesional/pacientes/${paciente.id}`}
                key={paciente.id}
                className="block hover:bg-violet-50 dark:hover:bg-violet-950/10"
              >
                <div className="grid grid-cols-12 gap-4 p-3 items-center">
                  <div className="col-span-4 flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center text-violet-700 dark:text-violet-300 font-semibold">
                      {paciente.nombre
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </div>
                    <div>
                      <p className="font-medium">{paciente.nombre}</p>
                      <p className="text-xs text-muted-foreground">{paciente.posicion}</p>
                    </div>
                  </div>
                  <div className="col-span-2">
                    <Badge className="bg-violet-500 hover:bg-violet-600">{paciente.deporte}</Badge>
                  </div>
                  <div className="col-span-2">
                    <p>{paciente.edad} años</p>
                    <p className="text-xs text-muted-foreground">{paciente.sexo}</p>
                  </div>
                  <div className="col-span-2">
                    <p>{paciente.ultimaEval}</p>
                  </div>
                  <div className="col-span-2 flex gap-2">
                    <div className="flex items-center gap-1">
                      <Weight className="h-4 w-4 text-violet-500" />
                      <span>{paciente.metricas.peso}</span>
                    </div>
                    <div className="flex items-center gap-1">
                      <Activity className="h-4 w-4 text-violet-500" />
                      <span>{paciente.metricas.grasa}%</span>
                    </div>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

