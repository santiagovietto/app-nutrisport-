import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Filter, LineChart, BarChart3, PieChart } from "lucide-react"

export default function EstadisticasPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">Estadísticas</h1>
        <div className="flex gap-2">
          <Select defaultValue="3m">
            <SelectTrigger className="w-[180px] border-violet-200 dark:border-violet-800">
              <SelectValue placeholder="Seleccionar período" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="1m">Último mes</SelectItem>
              <SelectItem value="3m">Últimos 3 meses</SelectItem>
              <SelectItem value="6m">Últimos 6 meses</SelectItem>
              <SelectItem value="1y">Último año</SelectItem>
              <SelectItem value="all">Todo el tiempo</SelectItem>
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            className="border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
          >
            <Filter className="mr-2 h-4 w-4" /> Filtros
          </Button>
        </div>
      </div>

      <Tabs defaultValue="general" className="space-y-4">
        <TabsList className="bg-violet-50 dark:bg-violet-950/20 border border-violet-100 dark:border-violet-900/20">
          <TabsTrigger value="general" className="data-[state=active]:bg-white dark:data-[state=active]:bg-background">
            General
          </TabsTrigger>
          <TabsTrigger value="deportes" className="data-[state=active]:bg-white dark:data-[state=active]:bg-background">
            Por Deportes
          </TabsTrigger>
          <TabsTrigger
            value="demograficos"
            className="data-[state=active]:bg-white dark:data-[state=active]:bg-background"
          >
            Demográficos
          </TabsTrigger>
          <TabsTrigger value="metricas" className="data-[state=active]:bg-white dark:data-[state=active]:bg-background">
            Métricas
          </TabsTrigger>
        </TabsList>

        <TabsContent value="general" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Total Pacientes</CardTitle>
                <CardDescription>Distribución por sexo</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-60 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                  <div className="text-center">
                    <PieChart className="h-8 w-8 mx-auto mb-2 text-violet-500" />
                    <p className="text-muted-foreground">Gráfico de distribución</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Evaluaciones</CardTitle>
                <CardDescription>Evolución mensual</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-60 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                  <div className="text-center">
                    <LineChart className="h-8 w-8 mx-auto mb-2 text-violet-500" />
                    <p className="text-muted-foreground">Gráfico de evolución</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Métricas Promedio</CardTitle>
                <CardDescription>Valores medios</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Peso promedio</span>
                      <span className="font-medium">72.5 kg</span>
                    </div>
                    <div className="w-full bg-violet-100 dark:bg-violet-950/40 rounded-full h-2">
                      <div className="bg-violet-500 h-2 rounded-full" style={{ width: "65%" }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>% Grasa promedio</span>
                      <span className="font-medium">18.2%</span>
                    </div>
                    <div className="w-full bg-violet-100 dark:bg-violet-950/40 rounded-full h-2">
                      <div className="bg-violet-500 h-2 rounded-full" style={{ width: "45%" }}></div>
                    </div>
                  </div>

                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>VO2 máx promedio</span>
                      <span className="font-medium">48.3 ml/kg/min</span>
                    </div>
                    <div className="w-full bg-violet-100 dark:bg-violet-950/40 rounded-full h-2">
                      <div className="bg-violet-500 h-2 rounded-full" style={{ width: "75%" }}></div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-violet-100 dark:border-violet-900/20">
            <CardHeader>
              <CardTitle>Evolución de Métricas</CardTitle>
              <CardDescription>Tendencias en el tiempo</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                <div className="text-center">
                  <LineChart className="h-8 w-8 mx-auto mb-2 text-violet-500" />
                  <p className="text-muted-foreground">Gráfico de evolución de métricas</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="deportes" className="space-y-4">
          <Card className="border-violet-100 dark:border-violet-900/20">
            <CardHeader>
              <CardTitle>Distribución por Deportes</CardTitle>
              <CardDescription>Pacientes por deporte</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                <div className="text-center">
                  <PieChart className="h-8 w-8 mx-auto mb-2 text-violet-500" />
                  <p className="text-muted-foreground">Gráfico de distribución por deportes</p>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="border-violet-100 dark:border-violet-900/20">
            <CardHeader>
              <CardTitle>Métricas por Deporte</CardTitle>
              <CardDescription>Comparativa entre deportes</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                <div className="text-center">
                  <BarChart3 className="h-8 w-8 mx-auto mb-2 text-violet-500" />
                  <p className="text-muted-foreground">Gráfico comparativo de métricas por deporte</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="demograficos" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Distribución por Edad</CardTitle>
                <CardDescription>Pacientes por rango de edad</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-60 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                  <div className="text-center">
                    <BarChart3 className="h-8 w-8 mx-auto mb-2 text-violet-500" />
                    <p className="text-muted-foreground">Gráfico de distribución por edad</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Distribución por Sexo</CardTitle>
                <CardDescription>Pacientes por sexo</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-60 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                  <div className="text-center">
                    <PieChart className="h-8 w-8 mx-auto mb-2 text-violet-500" />
                    <p className="text-muted-foreground">Gráfico de distribución por sexo</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-violet-100 dark:border-violet-900/20">
            <CardHeader>
              <CardTitle>Métricas por Grupo Demográfico</CardTitle>
              <CardDescription>Comparativa entre grupos</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                <div className="text-center">
                  <BarChart3 className="h-8 w-8 mx-auto mb-2 text-violet-500" />
                  <p className="text-muted-foreground">Gráfico comparativo de métricas por grupo demográfico</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="metricas" className="space-y-4">
          <div className="grid gap-4 md:grid-cols-3">
            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Peso</CardTitle>
                <CardDescription>Distribución y tendencias</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-60 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                  <div className="text-center">
                    <LineChart className="h-8 w-8 mx-auto mb-2 text-violet-500" />
                    <p className="text-muted-foreground">Gráfico de peso</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>% Grasa Corporal</CardTitle>
                <CardDescription>Distribución y tendencias</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-60 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                  <div className="text-center">
                    <LineChart className="h-8 w-8 mx-auto mb-2 text-violet-500" />
                    <p className="text-muted-foreground">Gráfico de % grasa</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>VO2 Máx</CardTitle>
                <CardDescription>Distribución y tendencias</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-60 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                  <div className="text-center">
                    <LineChart className="h-8 w-8 mx-auto mb-2 text-violet-500" />
                    <p className="text-muted-foreground">Gráfico de VO2 máx</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card className="border-violet-100 dark:border-violet-900/20">
            <CardHeader>
              <CardTitle>Correlación entre Métricas</CardTitle>
              <CardDescription>Relaciones entre diferentes métricas</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-80 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                <div className="text-center">
                  <LineChart className="h-8 w-8 mx-auto mb-2 text-violet-500" />
                  <p className="text-muted-foreground">Gráfico de correlación entre métricas</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}

