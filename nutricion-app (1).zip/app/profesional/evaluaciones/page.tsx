import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Plus, Search, Filter, Calendar } from "lucide-react"
import Link from "next/link"
import { Input } from "@/components/ui/input"

export default function EvaluacionesPage() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">Evaluaciones</h1>
        <Button asChild className="bg-violet-500 hover:bg-violet-600">
          <Link href="/profesional/evaluaciones/nueva">
            <Plus className="mr-2 h-4 w-4" /> Nueva Evaluación
          </Link>
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Buscar evaluación..."
            className="pl-8 border-violet-200 dark:border-violet-800"
          />
        </div>
        <Button
          variant="outline"
          className="sm:w-auto w-full border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
        >
          <Filter className="mr-2 h-4 w-4" /> Filtros
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {[
          { id: 1, paciente: "Carlos Rodríguez", fecha: "22/03/2025", tipo: "Completa" },
          { id: 2, paciente: "Ana Martínez", fecha: "21/03/2025", tipo: "Parcial" },
          { id: 3, paciente: "Juan López", fecha: "20/03/2025", tipo: "Completa" },
          { id: 4, paciente: "María García", fecha: "19/03/2025", tipo: "Completa" },
          { id: 5, paciente: "Pedro Sánchez", fecha: "18/03/2025", tipo: "Parcial" },
          { id: 6, paciente: "Laura Fernández", fecha: "17/03/2025", tipo: "Completa" },
        ].map((evaluacion) => (
          <Link href={`/profesional/evaluaciones/${evaluacion.id}`} key={evaluacion.id}>
            <Card className="cursor-pointer hover:shadow-md transition-shadow border-violet-100 dark:border-violet-900/20">
              <CardHeader className="pb-2">
                <CardTitle className="text-lg">{evaluacion.paciente}</CardTitle>
                <CardDescription className="flex items-center">
                  <Calendar className="h-3 w-3 mr-1" />
                  {evaluacion.fecha}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex justify-between items-center">
                  <span className="text-sm text-muted-foreground">Evaluación {evaluacion.tipo}</span>
                  <Button
                    variant="outline"
                    size="sm"
                    className="border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                  >
                    Ver detalles
                  </Button>
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  )
}

