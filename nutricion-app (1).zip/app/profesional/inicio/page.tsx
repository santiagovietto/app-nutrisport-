"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertCircle,
  Plus,
  Users,
  ArrowRightLeft,
  TrendingUp,
  Weight,
  Heart,
  Activity,
  ClipboardList,
  Filter,
  BarChart3,
  LineChart,
  Home,
  Bell,
  Clock,
  BarChart,
} from "lucide-react"
import Link from "next/link"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"

export default function ProfesionalInicio() {
  const [activeTab, setActiveTab] = useState("resumen")
  const [chartView, setChartView] = useState("line")
  const [timeRange, setTimeRange] = useState("3m")
  const [filterSport, setFilterSport] = useState("todos")
  const [filterGender, setFilterGender] = useState("todos")
  const [filterAge, setFilterAge] = useState("todas")
  const [filterPosition, setFilterPosition] = useState("todas")
  const [showFilters, setShowFilters] = useState(false)

  return (
    <div className="space-y-6 pb-16">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">Panel de Control</h1>
        <Button asChild className="bg-violet-500 hover:bg-violet-600">
          <Link href="/profesional/evaluaciones/nueva">
            <Plus className="mr-2 h-4 w-4" /> Nueva Evaluación
          </Link>
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Link href="/profesional/pacientes">
          <Card className="bg-gradient-to-br from-violet-50 to-white dark:from-violet-950/20 dark:to-background border-violet-100 dark:border-violet-900/20 hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Pacientes</CardTitle>
              <Users className="h-4 w-4 text-violet-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">24</div>
              <p className="text-xs text-muted-foreground">+2 este mes</p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/profesional/evaluaciones">
          <Card className="bg-gradient-to-br from-violet-50 to-white dark:from-violet-950/20 dark:to-background border-violet-100 dark:border-violet-900/20 hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Evaluaciones</CardTitle>
              <ClipboardList className="h-4 w-4 text-violet-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">42</div>
              <p className="text-xs text-muted-foreground">+8 este mes</p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/profesional/estadisticas/comparar">
          <Card className="bg-gradient-to-br from-violet-50 to-white dark:from-violet-950/20 dark:to-background border-violet-100 dark:border-violet-900/20 hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Comparaciones</CardTitle>
              <ArrowRightLeft className="h-4 w-4 text-violet-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12</div>
              <p className="text-xs text-muted-foreground">+3 este mes</p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/profesional/estadisticas">
          <Card className="bg-gradient-to-br from-violet-50 to-white dark:from-violet-950/20 dark:to-background border-violet-100 dark:border-violet-900/20 hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Tendencias</CardTitle>
              <TrendingUp className="h-4 w-4 text-violet-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">7</div>
              <p className="text-xs text-muted-foreground">Factores en seguimiento</p>
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* Contenido basado en pestañas */}
      <div className="space-y-4">
        {activeTab === "resumen" && (
          <div className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Link href="/profesional/estadisticas?metrica=peso">
                <Card className="hover:shadow-md transition-shadow cursor-pointer border-violet-100 dark:border-violet-900/20">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex justify-between items-center">
                      <span>Peso Promedio</span>
                      <Badge
                        variant="outline"
                        className="bg-violet-50 dark:bg-violet-950/20 text-violet-700 dark:text-violet-300 hover:bg-violet-100 dark:hover:bg-violet-900/40"
                      >
                        Ver detalle
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl font-bold">72.5 kg</div>
                      <p className="text-xs text-muted-foreground">Todos los pacientes</p>
                    </div>
                    <Weight className="h-8 w-8 text-violet-500" />
                  </CardContent>
                </Card>
              </Link>
              <Link href="/profesional/estadisticas?metrica=grasa">
                <Card className="hover:shadow-md transition-shadow cursor-pointer border-violet-100 dark:border-violet-900/20">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex justify-between items-center">
                      <span>% Grasa Promedio</span>
                      <Badge
                        variant="outline"
                        className="bg-violet-50 dark:bg-violet-950/20 text-violet-700 dark:text-violet-300 hover:bg-violet-100 dark:hover:bg-violet-900/40"
                      >
                        Ver detalle
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl font-bold">18.2%</div>
                      <p className="text-xs text-muted-foreground">Todos los pacientes</p>
                    </div>
                    <Activity className="h-8 w-8 text-violet-500" />
                  </CardContent>
                </Card>
              </Link>
              <Link href="/profesional/estadisticas?metrica=vo2">
                <Card className="hover:shadow-md transition-shadow cursor-pointer border-violet-100 dark:border-violet-900/20">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-sm font-medium flex justify-between items-center">
                      <span>VO2 Máx Promedio</span>
                      <Badge
                        variant="outline"
                        className="bg-violet-50 dark:bg-violet-950/20 text-violet-700 dark:text-violet-300 hover:bg-violet-100 dark:hover:bg-violet-900/40"
                      >
                        Ver detalle
                      </Badge>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="flex items-center justify-between">
                    <div>
                      <div className="text-2xl font-bold">48.3</div>
                      <p className="text-xs text-muted-foreground">ml/kg/min</p>
                    </div>
                    <Heart className="h-8 w-8 text-violet-500" />
                  </CardContent>
                </Card>
              </Link>
            </div>

            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Últimas Evaluaciones</CardTitle>
                <CardDescription>Evaluaciones realizadas recientemente</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {[
                    { name: "Carlos Rodríguez", date: "22/03/2025", type: "Completa", sport: "Fútbol", id: 1 },
                    { name: "Ana Martínez", date: "21/03/2025", type: "Parcial", sport: "Baloncesto", id: 2 },
                    { name: "Juan López", date: "20/03/2025", type: "Completa", sport: "Natación", id: 3 },
                    { name: "María García", date: "19/03/2025", type: "Completa", sport: "Atletismo", id: 4 },
                    { name: "Pedro Sánchez", date: "18/03/2025", type: "Parcial", sport: "Fútbol", id: 5 },
                  ].map((evaluation, index) => (
                    <Link href={`/profesional/evaluaciones/${evaluation.id}`} key={index}>
                      <div className="flex justify-between items-center p-3 rounded-lg hover:bg-violet-50 dark:hover:bg-violet-950/20 transition-colors">
                        <div className="flex items-center gap-3">
                          <div className="h-10 w-10 rounded-full bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center text-violet-700 dark:text-violet-300 font-semibold">
                            {evaluation.name
                              .split(" ")
                              .map((n) => n[0])
                              .join("")}
                          </div>
                          <div>
                            <p className="font-medium">{evaluation.name}</p>
                            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                              <span>{evaluation.date}</span>
                              <span>•</span>
                              <span>{evaluation.sport}</span>
                            </div>
                          </div>
                        </div>
                        <Badge
                          variant={index === 0 ? "default" : "outline"}
                          className={index === 0 ? "bg-violet-500 hover:bg-violet-600" : ""}
                        >
                          {evaluation.type}
                        </Badge>
                      </div>
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "alertas" && (
          <div className="space-y-4">
            <Alert variant="destructive">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Alerta de Peso</AlertTitle>
              <AlertDescription>3 pacientes han aumentado más de 5% de peso en el último mes.</AlertDescription>
            </Alert>
            <Alert className="border-violet-200 dark:border-violet-800 bg-violet-50 dark:bg-violet-950/20 text-violet-800 dark:text-violet-300">
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Recordatorio</AlertTitle>
              <AlertDescription>5 pacientes necesitan actualizar su evaluación antropométrica.</AlertDescription>
            </Alert>

            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Pacientes con Alertas</CardTitle>
                <CardDescription>Pacientes que requieren atención</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {[
                    {
                      name: "Carlos Rodríguez",
                      alert: "Aumento de peso",
                      severity: "high",
                      lastEval: "22/03/2025",
                      id: 1,
                    },
                    {
                      name: "Ana Martínez",
                      alert: "Disminución de masa muscular",
                      severity: "medium",
                      lastEval: "15/02/2025",
                      id: 2,
                    },
                    {
                      name: "Juan López",
                      alert: "Evaluación pendiente",
                      severity: "low",
                      lastEval: "10/01/2025",
                      id: 3,
                    },
                  ].map((patient, index) => (
                    <Link href={`/profesional/pacientes/${patient.id}`} key={index}>
                      <div className="flex justify-between items-center p-3 rounded-lg hover:bg-violet-50 dark:hover:bg-violet-950/20 transition-colors">
                        <div className="flex items-center gap-3">
                          <div
                            className={`h-2 w-2 rounded-full ${
                              patient.severity === "high"
                                ? "bg-red-500"
                                : patient.severity === "medium"
                                  ? "bg-amber-500"
                                  : "bg-blue-500"
                            }`}
                          />
                          <div>
                            <p className="font-medium">{patient.name}</p>
                            <p className="text-xs text-muted-foreground">Última evaluación: {patient.lastEval}</p>
                          </div>
                        </div>
                        <div>
                          <Badge
                            variant="outline"
                            className={
                              patient.severity === "high"
                                ? "border-red-200 bg-red-50 text-red-700 dark:border-red-900 dark:bg-red-950/20 dark:text-red-300"
                                : patient.severity === "medium"
                                  ? "border-amber-200 bg-amber-50 text-amber-700 dark:border-amber-900 dark:bg-amber-950/20 dark:text-amber-300"
                                  : "border-blue-200 bg-blue-50 text-blue-700 dark:border-blue-900 dark:bg-blue-950/20 dark:text-blue-300"
                            }
                          >
                            {patient.alert}
                          </Badge>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "recientes" && (
          <div className="space-y-4">
            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Evaluaciones Recientes</CardTitle>
                <CardDescription>Últimas 5 evaluaciones realizadas</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {[
                    {
                      name: "Carlos Rodríguez",
                      date: "22/03/2025",
                      type: "Completa",
                      metrics: { weight: 75.2, fat: 12.5, vo2: 48.3 },
                      id: 1,
                    },
                    {
                      name: "Ana Martínez",
                      date: "21/03/2025",
                      type: "Parcial",
                      metrics: { weight: 62.4, fat: 18.2, vo2: 42.1 },
                      id: 2,
                    },
                    {
                      name: "Juan López",
                      date: "20/03/2025",
                      type: "Completa",
                      metrics: { weight: 80.1, fat: 14.3, vo2: 46.8 },
                      id: 3,
                    },
                    {
                      name: "María García",
                      date: "19/03/2025",
                      type: "Completa",
                      metrics: { weight: 58.7, fat: 19.5, vo2: 44.2 },
                      id: 4,
                    },
                    {
                      name: "Pedro Sánchez",
                      date: "18/03/2025",
                      type: "Parcial",
                      metrics: { weight: 82.3, fat: 15.8, vo2: 45.6 },
                      id: 5,
                    },
                  ].map((evaluation, index) => (
                    <Link href={`/profesional/evaluaciones/${evaluation.id}`} key={index}>
                      <div className="border rounded-lg p-4 hover:shadow-md transition-shadow">
                        <div className="flex justify-between items-center mb-3">
                          <div className="flex items-center gap-3">
                            <div className="h-10 w-10 rounded-full bg-violet-100 dark:bg-violet-900/30 flex items-center justify-center text-violet-700 dark:text-violet-300 font-semibold">
                              {evaluation.name
                                .split(" ")
                                .map((n) => n[0])
                                .join("")}
                            </div>
                            <div>
                              <p className="font-medium">{evaluation.name}</p>
                              <p className="text-xs text-muted-foreground">{evaluation.date}</p>
                            </div>
                          </div>
                          <Badge
                            variant={index === 0 ? "default" : "outline"}
                            className={index === 0 ? "bg-violet-500 hover:bg-violet-600" : ""}
                          >
                            {evaluation.type}
                          </Badge>
                        </div>
                        <div className="grid grid-cols-3 gap-4 mt-4">
                          <div className="flex flex-col items-center p-2 rounded-lg bg-violet-50 dark:bg-violet-950/20">
                            <Weight className="h-4 w-4 text-violet-500 mb-1" />
                            <span className="text-xs text-muted-foreground">Peso</span>
                            <span className="font-medium">{evaluation.metrics.weight} kg</span>
                          </div>
                          <div className="flex flex-col items-center p-2 rounded-lg bg-violet-50 dark:bg-violet-950/20">
                            <Activity className="h-4 w-4 text-violet-500 mb-1" />
                            <span className="text-xs text-muted-foreground">% Grasa</span>
                            <span className="font-medium">{evaluation.metrics.fat}%</span>
                          </div>
                          <div className="flex flex-col items-center p-2 rounded-lg bg-violet-50 dark:bg-violet-950/20">
                            <Heart className="h-4 w-4 text-violet-500 mb-1" />
                            <span className="text-xs text-muted-foreground">VO2 Máx</span>
                            <span className="font-medium">{evaluation.metrics.vo2}</span>
                          </div>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "comparativas" && (
          <div className="space-y-4">
            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Comparación de Métricas</CardTitle>
                <CardDescription>Compara métricas entre pacientes aplicando filtros</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <Button
                    variant="outline"
                    onClick={() => setShowFilters(!showFilters)}
                    className="border-violet-200 dark:border-violet-800"
                  >
                    <Filter className="mr-2 h-4 w-4" /> {showFilters ? "Ocultar filtros" : "Mostrar filtros"}
                  </Button>
                  <div className="flex items-center gap-2">
                    <Button
                      variant={chartView === "line" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setChartView("line")}
                      className={
                        chartView === "line"
                          ? "bg-violet-500 hover:bg-violet-600"
                          : "border-violet-200 dark:border-violet-800"
                      }
                    >
                      <LineChart className="h-4 w-4 mr-1" /> Línea
                    </Button>
                    <Button
                      variant={chartView === "bar" ? "default" : "outline"}
                      size="sm"
                      onClick={() => setChartView("bar")}
                      className={
                        chartView === "bar"
                          ? "bg-violet-500 hover:bg-violet-600"
                          : "border-violet-200 dark:border-violet-800"
                      }
                    >
                      <BarChart3 className="h-4 w-4 mr-1" /> Barras
                    </Button>
                    <Select value={timeRange} onValueChange={setTimeRange}>
                      <SelectTrigger className="w-[140px] border-violet-200 dark:border-violet-800">
                        <SelectValue placeholder="Período" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="1m">Último mes</SelectItem>
                        <SelectItem value="3m">Últimos 3 meses</SelectItem>
                        <SelectItem value="6m">Últimos 6 meses</SelectItem>
                        <SelectItem value="1y">Último año</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {showFilters && (
                  <div className="grid grid-cols-1 md:grid-cols-4 gap-4 p-4 bg-violet-50 dark:bg-violet-950/20 rounded-lg">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Deporte</label>
                      <Select value={filterSport} onValueChange={setFilterSport}>
                        <SelectTrigger className="border-violet-200 dark:border-violet-800">
                          <SelectValue placeholder="Todos los deportes" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="todos">Todos los deportes</SelectItem>
                          <SelectItem value="futbol">Fútbol</SelectItem>
                          <SelectItem value="baloncesto">Baloncesto</SelectItem>
                          <SelectItem value="natacion">Natación</SelectItem>
                          <SelectItem value="atletismo">Atletismo</SelectItem>
                          <SelectItem value="tenis">Tenis</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Sexo</label>
                      <Select value={filterGender} onValueChange={setFilterGender}>
                        <SelectTrigger className="border-violet-200 dark:border-violet-800">
                          <SelectValue placeholder="Todos" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="todos">Todos</SelectItem>
                          <SelectItem value="masculino">Masculino</SelectItem>
                          <SelectItem value="femenino">Femenino</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Edad</label>
                      <Select value={filterAge} onValueChange={setFilterAge}>
                        <SelectTrigger className="border-violet-200 dark:border-violet-800">
                          <SelectValue placeholder="Todas las edades" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="todas">Todas las edades</SelectItem>
                          <SelectItem value="18-25">18-25 años</SelectItem>
                          <SelectItem value="26-35">26-35 años</SelectItem>
                          <SelectItem value="36-45">36-45 años</SelectItem>
                          <SelectItem value="46+">46+ años</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Posición</label>
                      <Select value={filterPosition} onValueChange={setFilterPosition}>
                        <SelectTrigger className="border-violet-200 dark:border-violet-800">
                          <SelectValue placeholder="Todas las posiciones" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="todas">Todas las posiciones</SelectItem>
                          <SelectItem value="delantero">Delantero</SelectItem>
                          <SelectItem value="defensa">Defensa</SelectItem>
                          <SelectItem value="centrocampista">Centrocampista</SelectItem>
                          <SelectItem value="base">Base</SelectItem>
                          <SelectItem value="alero">Alero</SelectItem>
                          <SelectItem value="velocista">Velocista</SelectItem>
                          <SelectItem value="fondista">Fondista</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                )}

                <div className="pt-4">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-medium">Comparativa de % Grasa Corporal</h3>
                    <Badge
                      variant="outline"
                      className="bg-violet-50 dark:bg-violet-950/20 text-violet-700 dark:text-violet-300 hover:bg-violet-100 dark:hover:bg-violet-900/40 cursor-pointer"
                    >
                      Ver detalle
                    </Badge>
                  </div>
                  <div className="h-80 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground mb-2">Gráfico comparativo de % grasa corporal</p>
                      <p className="text-xs text-muted-foreground">Haz clic para ver detalles</p>
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-medium">Comparativa de IMC</h3>
                    <Badge
                      variant="outline"
                      className="bg-violet-50 dark:bg-violet-950/20 text-violet-700 dark:text-violet-300 hover:bg-violet-100 dark:hover:bg-violet-900/40 cursor-pointer"
                    >
                      Ver detalle
                    </Badge>
                  </div>
                  <div className="h-80 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground mb-2">Gráfico comparativo de IMC</p>
                      <p className="text-xs text-muted-foreground">Haz clic para ver detalles</p>
                    </div>
                  </div>
                </div>

                <div className="pt-4">
                  <div className="flex justify-between items-center mb-4">
                    <h3 className="text-lg font-medium">Comparativa de Somatotipo</h3>
                    <Badge
                      variant="outline"
                      className="bg-violet-50 dark:bg-violet-950/20 text-violet-700 dark:text-violet-300 hover:bg-violet-100 dark:hover:bg-violet-900/40 cursor-pointer"
                    >
                      Ver detalle
                    </Badge>
                  </div>
                  <div className="h-80 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                    <div className="text-center">
                      <p className="text-muted-foreground mb-2">Gráfico comparativo de somatotipo</p>
                      <p className="text-xs text-muted-foreground">Haz clic para ver detalles</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {/* Pestañas en la parte inferior con iconos */}
      <div className="fixed bottom-0 left-0 right-0 bg-background border-t border-border z-10">
        <div className="w-full flex justify-around rounded-none bg-transparent border-0 p-2">
          <button
            onClick={() => setActiveTab("resumen")}
            className={`flex flex-col items-center gap-1 h-auto py-2 px-4 ${activeTab === "resumen" ? "bg-violet-50 dark:bg-violet-950/20 text-violet-700 dark:text-violet-300" : ""} rounded-md`}
          >
            <Home className="h-5 w-5" />
            <span className="text-xs">Resumen</span>
          </button>
          <button
            onClick={() => setActiveTab("alertas")}
            className={`flex flex-col items-center gap-1 h-auto py-2 px-4 ${activeTab === "alertas" ? "bg-violet-50 dark:bg-violet-950/20 text-violet-700 dark:text-violet-300" : ""} rounded-md`}
          >
            <Bell className="h-5 w-5" />
            <span className="text-xs">Alertas</span>
          </button>
          <button
            onClick={() => setActiveTab("recientes")}
            className={`flex flex-col items-center gap-1 h-auto py-2 px-4 ${activeTab === "recientes" ? "bg-violet-50 dark:bg-violet-950/20 text-violet-700 dark:text-violet-300" : ""} rounded-md`}
          >
            <Clock className="h-5 w-5" />
            <span className="text-xs">Recientes</span>
          </button>
          <button
            onClick={() => setActiveTab("comparativas")}
            className={`flex flex-col items-center gap-1 h-auto py-2 px-4 ${activeTab === "comparativas" ? "bg-violet-50 dark:bg-violet-950/20 text-violet-700 dark:text-violet-300" : ""} rounded-md`}
          >
            <BarChart className="h-5 w-5" />
            <span className="text-xs">Comparativas</span>
          </button>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold">Accesos Rápidos</h2>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        <Button
          asChild
          variant="outline"
          className="h-24 flex flex-col gap-2 border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20 hover:border-violet-300 dark:hover:border-violet-700"
        >
          <Link href="/profesional/pacientes">
            <Users className="h-6 w-6 text-violet-500" />
            <span>Ver Pacientes</span>
          </Link>
        </Button>
        <Button
          asChild
          variant="outline"
          className="h-24 flex flex-col gap-2 border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20 hover:border-violet-300 dark:hover:border-violet-700"
        >
          <Link href="/profesional/evaluaciones/nueva">
            <ClipboardList className="h-6 w-6 text-violet-500" />
            <span>Nueva Evaluación</span>
          </Link>
        </Button>
        <Button
          asChild
          variant="outline"
          className="h-24 flex flex-col gap-2 border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20 hover:border-violet-300 dark:hover:border-violet-700"
        >
          <Link href="/profesional/estadisticas/comparar">
            <ArrowRightLeft className="h-6 w-6 text-violet-500" />
            <span>Comparar Métricas</span>
          </Link>
        </Button>
      </div>
    </div>
  )
}

