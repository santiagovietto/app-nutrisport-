"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Weight,
  Heart,
  Activity,
  Calendar,
  FileText,
  Download,
  LineChart,
  Home,
  TrendingUp,
  Utensils,
  Target,
} from "lucide-react"
import Link from "next/link"

export default function UsuarioInicio() {
  const [activeTab, setActiveTab] = useState("resumen")

  return (
    <div className="space-y-6 pb-16">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold tracking-tight">Bienvenido, Carlos</h1>
        <Badge className="bg-violet-500">Fútbol - Delantero</Badge>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Link href="/usuario/evaluaciones">
          <Card className="bg-gradient-to-br from-violet-50 to-white dark:from-violet-950/20 dark:to-background border-violet-100 dark:border-violet-900/20 hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Peso Actual</CardTitle>
              <Weight className="h-4 w-4 text-violet-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">75.2 kg</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-green-500">↓ 0.9 kg</span> desde la última evaluación
              </p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/usuario/evaluaciones?metrica=grasa">
          <Card className="bg-gradient-to-br from-violet-50 to-white dark:from-violet-950/20 dark:to-background border-violet-100 dark:border-violet-900/20 hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">% Grasa Corporal</CardTitle>
              <Activity className="h-4 w-4 text-violet-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">12.5%</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-green-500">↓ 0.7%</span> desde la última evaluación
              </p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/usuario/evaluaciones?metrica=vo2">
          <Card className="bg-gradient-to-br from-violet-50 to-white dark:from-violet-950/20 dark:to-background border-violet-100 dark:border-violet-900/20 hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">VO2 Máx</CardTitle>
              <Heart className="h-4 w-4 text-violet-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">48.3</div>
              <p className="text-xs text-muted-foreground">
                <span className="text-green-500">↑ 1.5</span> desde la última evaluación
              </p>
            </CardContent>
          </Card>
        </Link>
        <Link href="/usuario/evaluaciones/proxima">
          <Card className="bg-gradient-to-br from-violet-50 to-white dark:from-violet-950/20 dark:to-background border-violet-100 dark:border-violet-900/20 hover:shadow-md transition-shadow cursor-pointer">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Próxima Evaluación</CardTitle>
              <Calendar className="h-4 w-4 text-violet-500" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">15/04/2025</div>
              <p className="text-xs text-muted-foreground">En 24 días</p>
            </CardContent>
          </Card>
        </Link>
      </div>

      {/* Contenido basado en pestañas */}
      <div className="space-y-4">
        {activeTab === "resumen" && (
          <div className="space-y-4">
            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Última Evaluación</CardTitle>
                <CardDescription>Realizada el 15/03/2025</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-1">
                      <Weight className="h-3 w-3 text-violet-500" />
                      <span className="text-xs font-medium">Peso</span>
                    </div>
                    <span className="text-sm">75.2 kg</span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-1">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="12"
                        height="12"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="text-violet-500"
                      >
                        <path d="M12 2v20M2 12h20" />
                      </svg>
                      <span className="text-xs font-medium">Talla</span>
                    </div>
                    <span className="text-sm">180 cm</span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-1">
                      <Activity className="h-3 w-3 text-violet-500" />
                      <span className="text-xs font-medium">IMC</span>
                    </div>
                    <span className="text-sm">23.2</span>
                  </div>
                  <div className="flex flex-col gap-1">
                    <div className="flex items-center gap-1">
                      <Heart className="h-3 w-3 text-violet-500" />
                      <span className="text-xs font-medium">% Grasa</span>
                    </div>
                    <span className="text-sm">12.5%</span>
                  </div>
                </div>

                <Button
                  asChild
                  variant="outline"
                  size="sm"
                  className="w-full border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                >
                  <Link href="/usuario/evaluaciones">Ver evaluación completa</Link>
                </Button>
              </CardContent>
            </Card>

            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Plan Alimentario Actual</CardTitle>
                <CardDescription>Plan Nutricional - Fase de Definición</CardDescription>
              </CardHeader>
              <CardContent>
                <p className="text-sm mb-4">
                  Este plan está diseñado para ayudarte a reducir el porcentaje de grasa corporal manteniendo tu masa
                  muscular y rendimiento deportivo.
                </p>

                <div className="flex justify-between">
                  <Button
                    asChild
                    variant="outline"
                    className="border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                  >
                    <Link href="/usuario/plan">
                      <FileText className="mr-2 h-4 w-4" /> Ver plan completo
                    </Link>
                  </Button>
                  <Button
                    asChild
                    variant="outline"
                    className="border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                  >
                    <Link href="#">
                      <Download className="mr-2 h-4 w-4" /> Descargar PDF
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Metas Actuales</CardTitle>
                <CardDescription>Progreso de tus objetivos</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Reducción de grasa corporal</span>
                      <span className="text-sm">70%</span>
                    </div>
                    <div className="w-full bg-violet-100 dark:bg-violet-950/40 rounded-full h-2.5">
                      <div className="bg-violet-500 h-2.5 rounded-full" style={{ width: "70%" }}></div>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">Meta: 10% de grasa corporal para el 15/04/2025</p>
                  </div>

                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm font-medium">Mejora de VO2 máx</span>
                      <span className="text-sm">45%</span>
                    </div>
                    <div className="w-full bg-violet-100 dark:bg-violet-950/40 rounded-full h-2.5">
                      <div className="bg-violet-500 h-2.5 rounded-full" style={{ width: "45%" }}></div>
                    </div>
                    <p className="text-xs text-muted-foreground mt-1">Meta: 50 ml/kg/min para el 15/06/2025</p>
                  </div>
                </div>

                <Button
                  asChild
                  variant="outline"
                  size="sm"
                  className="w-full mt-4 border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                >
                  <Link href="/usuario/metas">Ver todas las metas</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "tendencias" && (
          <div className="space-y-4">
            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Evolución del Peso</CardTitle>
                <CardDescription>Últimos 3 meses</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                  <div className="text-center">
                    <LineChart className="h-8 w-8 mx-auto mb-2 text-violet-500" />
                    <p className="text-muted-foreground">Gráfico de evolución del peso</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Evolución del % de Grasa Corporal</CardTitle>
                <CardDescription>Últimos 3 meses</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                  <div className="text-center">
                    <LineChart className="h-8 w-8 mx-auto mb-2 text-violet-500" />
                    <p className="text-muted-foreground">Gráfico de evolución del % de grasa</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Comparativa con Grupo</CardTitle>
                <CardDescription>Comparación con delanteros de fútbol</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="h-64 bg-violet-50 dark:bg-violet-950/20 rounded-md flex items-center justify-center">
                  <div className="text-center">
                    <LineChart className="h-8 w-8 mx-auto mb-2 text-violet-500" />
                    <p className="text-muted-foreground">Gráfico comparativo con grupo</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "plan" && (
          <div className="space-y-4">
            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Plan Nutricional - Fase de Definición</CardTitle>
                <CardDescription>Actualizado el 15/03/2025</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <h3 className="text-sm font-medium mb-2">Objetivos del Plan</h3>
                    <p className="text-sm">
                      Este plan está diseñado para ayudarte a reducir el porcentaje de grasa corporal manteniendo tu
                      masa muscular y rendimiento deportivo.
                    </p>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium mb-2">Distribución de Macronutrientes</h3>
                    <div className="grid grid-cols-3 gap-2">
                      <div className="p-2 bg-violet-50 dark:bg-violet-950/20 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Proteínas</p>
                        <p className="font-medium">30%</p>
                        <p className="text-xs">180g</p>
                      </div>
                      <div className="p-2 bg-violet-50 dark:bg-violet-950/20 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Carbohidratos</p>
                        <p className="font-medium">45%</p>
                        <p className="text-xs">270g</p>
                      </div>
                      <div className="p-2 bg-violet-50 dark:bg-violet-950/20 rounded-lg text-center">
                        <p className="text-xs text-muted-foreground">Grasas</p>
                        <p className="font-medium">25%</p>
                        <p className="text-xs">67g</p>
                      </div>
                    </div>
                  </div>

                  <div>
                    <h3 className="text-sm font-medium mb-2">Calorías Diarias</h3>
                    <p className="text-sm">2400 kcal (días de entrenamiento) / 2100 kcal (días de descanso)</p>
                  </div>
                </div>

                <div className="flex justify-between mt-6">
                  <Button
                    asChild
                    variant="outline"
                    className="border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                  >
                    <Link href="/usuario/plan">
                      <FileText className="mr-2 h-4 w-4" /> Ver plan completo
                    </Link>
                  </Button>
                  <Button
                    asChild
                    variant="outline"
                    className="border-violet-200 dark:border-violet-800 hover:bg-violet-50 dark:hover:bg-violet-950/20"
                  >
                    <Link href="#">
                      <Download className="mr-2 h-4 w-4" /> Descargar PDF
                    </Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {activeTab === "metas" && (
          <div className="space-y-4">
            <Card className="border-violet-100 dark:border-violet-900/20">
              <CardHeader>
                <CardTitle>Metas y Objetivos</CardTitle>
                <CardDescription>Progreso de tus objetivos actuales</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="font-medium">Reducción de grasa corporal</span>
                      <span>70%</span>
                    </div>
                    <div className="w-full bg-violet-100 dark:bg-violet-950/40 rounded-full h-2.5">
                      <div className="bg-violet-500 h-2.5 rounded-full" style={{ width: "70%" }}></div>
                    </div>
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>Inicio: 14.1%</span>
                      <span>Actual: 12.5%</span>
                      <span>Meta: 10%</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">Fecha objetivo: 15/04/2025 (24 días restantes)</p>
                    <p className="text-sm mt-2">
                      Reducir el porcentaje de grasa corporal al 10% manteniendo la masa muscular.
                    </p>
                  </div>

                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="font-medium">Mejora de VO2 máx</span>
                      <span>45%</span>
                    </div>
                    <div className="w-full bg-violet-100 dark:bg-violet-950/40 rounded-full h-2.5">
                      <div className="bg-violet-500 h-2.5 rounded-full" style={{ width: "45%" }}></div>
                    </div>
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                      <span>Inicio: 46.8</span>
                      <span>Actual: 48.3</span>
                      <span>Meta: 50</span>
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">Fecha objetivo: 15/06/2025 (85 días restantes)</p>
                    <p className="text-sm mt-2">
                      Aumentar el VO2 máx a 50 ml/kg/min para mejorar la resistencia cardiovascular.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}
      </div>

      {/* Pestañas en la parte inferior con iconos */}
      <div className="fixed bottom-0 left-0 right-0 bg-background border-t border-border z-10">
        <div className="w-full flex justify-around rounded-none bg-transparent border-0 p-2">
          <button
            onClick={() => setActiveTab("resumen")}
            className={`flex flex-col items-center gap-1 h-auto py-2 px-4 ${activeTab === "resumen" ? "bg-violet-50 dark:bg-violet-950/20 text-violet-700 dark:text-violet-300" : ""} rounded-md`}
          >
            <Home className="h-5 w-5" />
            <span className="text-xs">Resumen</span>
          </button>
          <button
            onClick={() => setActiveTab("tendencias")}
            className={`flex flex-col items-center gap-1 h-auto py-2 px-4 ${activeTab === "tendencias" ? "bg-violet-50 dark:bg-violet-950/20 text-violet-700 dark:text-violet-300" : ""} rounded-md`}
          >
            <TrendingUp className="h-5 w-5" />
            <span className="text-xs">Tendencias</span>
          </button>
          <button
            onClick={() => setActiveTab("plan")}
            className={`flex flex-col items-center gap-1 h-auto py-2 px-4 ${activeTab === "plan" ? "bg-violet-50 dark:bg-violet-950/20 text-violet-700 dark:text-violet-300" : ""} rounded-md`}
          >
            <Utensils className="h-5 w-5" />
            <span className="text-xs">Plan</span>
          </button>
          <button
            onClick={() => setActiveTab("metas")}
            className={`flex flex-col items-center gap-1 h-auto py-2 px-4 ${activeTab === "metas" ? "bg-violet-50 dark:bg-violet-950/20 text-violet-700 dark:text-violet-300" : ""} rounded-md`}
          >
            <Target className="h-5 w-5" />
            <span className="text-xs">Metas</span>
          </button>
        </div>
      </div>
    </div>
  )
}

