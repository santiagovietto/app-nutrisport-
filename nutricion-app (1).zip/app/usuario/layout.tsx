"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Home, User, FileText, BarChart3, Settings, Menu, LogOut } from "lucide-react"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import { ThemeToggle } from "@/components/theme-toggle"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { useRouter } from "next/navigation"

export default function UsuarioLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const router = useRouter()
  const [userType, setUserType] = useState<"profesional" | "usuario">("usuario")

  const handleUserTypeChange = (value: string) => {
    setUserType(value as "profesional" | "usuario")
  }

  const handleSwitchUserType = () => {
    if (userType === "profesional") {
      router.push("/profesional/inicio")
    }
  }

  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <div className="mr-4 hidden md:flex">
            <Link href="/usuario/inicio" className="mr-6 flex items-center space-x-2">
              <span className="font-bold">NutriSport</span>
              <span className="text-xs bg-violet-100 dark:bg-violet-900/30 text-violet-700 dark:text-violet-300 px-2 py-0.5 rounded-md">
                Atleta
              </span>
            </Link>
            <nav className="flex items-center space-x-6 text-sm font-medium">
              <Link
                href="/usuario/inicio"
                className="transition-colors hover:text-foreground/80 text-foreground/60 hover:text-foreground"
              >
                Inicio
              </Link>
              <Link
                href="/usuario/perfil"
                className="transition-colors hover:text-foreground/80 text-foreground/60 hover:text-foreground"
              >
                Mi Perfil
              </Link>
              <Link
                href="/usuario/evaluaciones"
                className="transition-colors hover:text-foreground/80 text-foreground/60 hover:text-foreground"
              >
                Evaluaciones
              </Link>
              <Link
                href="/usuario/plan"
                className="transition-colors hover:text-foreground/80 text-foreground/60 hover:text-foreground"
              >
                Plan Alimentario
              </Link>
            </nav>
          </div>
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline" size="icon" className="mr-2 md:hidden border-violet-200 dark:border-violet-800">
                <Menu className="h-5 w-5" />
                <span className="sr-only">Toggle Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="pr-0">
              <div className="px-7">
                <Link href="/usuario/inicio" className="flex items-center gap-2 mb-8 mt-4">
                  <span className="font-bold text-lg">NutriSport</span>
                  <span className="text-xs bg-violet-100 dark:bg-violet-900/30 text-violet-700 dark:text-violet-300 px-2 py-0.5 rounded-md">
                    Atleta
                  </span>
                </Link>
              </div>
              <nav className="grid gap-2 px-2">
                <Link
                  href="/usuario/inicio"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-foreground transition-all hover:bg-violet-50 dark:hover:bg-violet-950/20"
                >
                  <Home className="h-5 w-5 text-violet-500" />
                  <span>Inicio</span>
                </Link>
                <Link
                  href="/usuario/perfil"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-foreground transition-all hover:bg-violet-50 dark:hover:bg-violet-950/20"
                >
                  <User className="h-5 w-5 text-violet-500" />
                  <span>Mi Perfil</span>
                </Link>
                <Link
                  href="/usuario/evaluaciones"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-foreground transition-all hover:bg-violet-50 dark:hover:bg-violet-950/20"
                >
                  <FileText className="h-5 w-5 text-violet-500" />
                  <span>Evaluaciones</span>
                </Link>
                <Link
                  href="/usuario/plan"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-foreground transition-all hover:bg-violet-50 dark:hover:bg-violet-950/20"
                >
                  <BarChart3 className="h-5 w-5 text-violet-500" />
                  <span>Plan Alimentario</span>
                </Link>
                <Dialog>
                  <DialogTrigger asChild>
                    <button className="flex items-center gap-3 rounded-lg px-3 py-2 text-foreground transition-all hover:bg-violet-50 dark:hover:bg-violet-950/20 w-full text-left">
                      <Settings className="h-5 w-5 text-violet-500" />
                      <span>Configuración</span>
                    </button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Configuración de acceso</DialogTitle>
                      <DialogDescription>
                        Selecciona el tipo de usuario con el que deseas acceder a la plataforma.
                      </DialogDescription>
                    </DialogHeader>
                    <RadioGroup value={userType} onValueChange={handleUserTypeChange} className="grid gap-4 py-4">
                      <div className="flex items-center space-x-2 border p-4 rounded-md">
                        <RadioGroupItem value="profesional" id="profesional-mobile" />
                        <Label htmlFor="profesional-mobile" className="flex-1 cursor-pointer">
                          <div className="font-medium">Profesional</div>
                          <div className="text-sm text-muted-foreground">
                            Nutricionistas y profesionales del deporte
                          </div>
                        </Label>
                      </div>
                      <div className="flex items-center space-x-2 border p-4 rounded-md">
                        <RadioGroupItem value="usuario" id="usuario-mobile" />
                        <Label htmlFor="usuario-mobile" className="flex-1 cursor-pointer">
                          <div className="font-medium">Usuario</div>
                          <div className="text-sm text-muted-foreground">Deportistas y atletas</div>
                        </Label>
                      </div>
                    </RadioGroup>
                    <div className="flex justify-end">
                      <Button className="bg-violet-500 hover:bg-violet-600" onClick={handleSwitchUserType}>
                        Cambiar
                      </Button>
                    </div>
                  </DialogContent>
                </Dialog>
                <Link
                  href="/"
                  className="flex items-center gap-3 rounded-lg px-3 py-2 text-foreground transition-all hover:bg-violet-50 dark:hover:bg-violet-950/20"
                >
                  <LogOut className="h-5 w-5 text-violet-500" />
                  <span>Cerrar Sesión</span>
                </Link>
              </nav>
            </SheetContent>
          </Sheet>
          <div className="flex flex-1 items-center justify-between space-x-2 md:justify-end">
            <div className="w-full flex-1 md:w-auto md:flex-none">
              <Link href="/usuario/inicio" className="mr-6 flex items-center space-x-2 md:hidden">
                <span className="font-bold">NutriSport</span>
              </Link>
            </div>
            <nav className="flex items-center">
              <ThemeToggle />
              <Dialog>
                <DialogTrigger asChild>
                  <Button variant="ghost" size="icon" className="ml-2">
                    <Settings className="h-5 w-5" />
                    <span className="sr-only">Configuración</span>
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Configuración de acceso</DialogTitle>
                    <DialogDescription>
                      Selecciona el tipo de usuario con el que deseas acceder a la plataforma.
                    </DialogDescription>
                  </DialogHeader>
                  <RadioGroup value={userType} onValueChange={handleUserTypeChange} className="grid gap-4 py-4">
                    <div className="flex items-center space-x-2 border p-4 rounded-md">
                      <RadioGroupItem value="profesional" id="profesional-desktop" />
                      <Label htmlFor="profesional-desktop" className="flex-1 cursor-pointer">
                        <div className="font-medium">Profesional</div>
                        <div className="text-sm text-muted-foreground">Nutricionistas y profesionales del deporte</div>
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2 border p-4 rounded-md">
                      <RadioGroupItem value="usuario" id="usuario-desktop" />
                      <Label htmlFor="usuario-desktop" className="flex-1 cursor-pointer">
                        <div className="font-medium">Usuario</div>
                        <div className="text-sm text-muted-foreground">Deportistas y atletas</div>
                      </Label>
                    </div>
                  </RadioGroup>
                  <div className="flex justify-end">
                    <Button className="bg-violet-500 hover:bg-violet-600" onClick={handleSwitchUserType}>
                      Cambiar
                    </Button>
                  </div>
                </DialogContent>
              </Dialog>
            </nav>
          </div>
        </div>
      </header>
      <div className="container flex-1 py-6">{children}</div>
    </div>
  )
}

